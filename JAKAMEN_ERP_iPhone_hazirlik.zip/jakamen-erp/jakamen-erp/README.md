# JAKAMEN ERP — ilk bağlantı sürümü

Bu klasör, mevcut Supabase projesine bağlanmak üzere hazırlanmış bir başlangıç uygulamasıdır.

## Şu an çalışanlar
- Supabase e-posta/şifre girişi
- `profiles` tablosundan ad ve rol okuma
- `products` ve `product_variants` tablolarından veri okuma
- Barkod, model, ürün adı, renk ve beden ile arama
- Varyant bazında satış fiyatı ve stok görüntüleme
- Mobil uyumlu yönetim paneli

## Henüz etkin olmayanlar
- Ürün ekleme/düzenleme/silme
- Satış kaydı ve ödeme alma
- Satışla atomik stok düşme
- İade/iptal
- Cari tahsilat ve kasa işlemleri
- Personel yönetim ekranı

Bunlar mevcut şema, RLS ve veritabanı fonksiyonları tam doğrulanıp güvenli RPC işlemleri yazıldıktan sonra eklenecektir. Bu sürüm gerçek satış yapmak için hazır değildir.

## Kurulum
1. Bilgisayarda Node.js LTS kurulu olmalı.
2. Bu klasörü açın.
3. Terminalde klasöre girip `npm install` çalıştırın.
4. `.env.example` dosyasını `.env` adıyla kopyalayın.
5. Supabase Project Settings → API bölümünden Project URL ve **publishable key** (veya eski anon public key) değerlerini `.env` dosyasına girin.
6. `npm run dev` komutunu çalıştırın.

## Güvenlik
- `service_role` veya secret key tarayıcı uygulamasına kesinlikle konulmaz.
- Yalnızca publishable/anon public key kullanılır; erişim RLS politikalarıyla sınırlandırılır.
- `.env` dosyasını Git'e yüklemeyin.
- İlk bağlantı testi için Supabase Auth ile giriş yapın.

## Şema varsayımları
Uygulama, konuşmada doğrulanan alanları kullanır:
- `profiles(id, full_name, role)`
- `products(id, name, model_code, created_at)`
- `product_variants(id, product_id, barcode, color, size, sale_price, stock, created_at)`

`products` veya `product_variants` alan adları sizin gerçek tablolarınızda farklıysa, kodu buna göre uyarlamadan önce şemayı tekrar kontrol edin.

## iPhone'a uygulama gibi ekleme (yayınlandıktan sonra)
1. Uygulama HTTPS adresinde yayınlanmış olmalıdır.
2. iPhone'da bu adresi **Safari** ile açın.
3. Paylaş simgesine dokunun → **Ana Ekrana Ekle** → **Ekle**.
4. Ana ekrandaki JAKAMEN simgesinden açın.

Bu proje PWA manifesti, iPhone ana ekran simgesi ve temel uygulama kabuğu önbelleği içerir. ZIP dosyasını tek başına açmak uygulamayı telefona kurmaz; önce ücretsiz bir HTTPS barındırma hizmetine yayınlanması ve Supabase ortam değişkenlerinin ayarlanması gerekir. Çevrimdışı kullanımda canlı Supabase verileri çalışmaz.
